//
//  Car.h
//  Toyotas
//
//  Created by Matthew Mauro on 2016-10-11.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject

@property (nonatomic) NSString *model;



+ (void)setDefaultModel:(NSString *)aModel;

- (void)drive;

- (id) initWithModel:(NSString *)model;

- (id)initC;

@end
