//
//  Car.m
//  Toyotas
//
//  Created by Matthew Mauro on 2016-10-11.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//
#import "Car.h"

static NSString *_defaultModel;

@implementation Car {
    
}
@synthesize model = _model;


+ (void)setDefaultModel:(NSString *)aModel{
    _defaultModel = [aModel copy];
}


- (id) initWithModel:(NSString *) aModel{
    self = [super init];
    if(self){
        _model = [aModel copy];
        
    }
    NSLog(@"Created a %@", _model);
    return self;
}

- (id)initC{
    _model = @"Prius";
    NSLog(@"Created a %@", _model);
    return [self initWithModel:_model];
}



- (void)drive{
    
    NSString *currentDrive;
    currentDrive = self.model;
    NSLog(@"Currently driving a %@", currentDrive);
    
}


@end
