//
//  main.m
//  Toyotas
//
//  Created by Matthew Mauro on 2016-10-11.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        
        NSLog(@"Hello");
        
        
        
        Car *nissan = [[Car alloc]initWithModel:@"Rogue"];
        
        
        [nissan drive];
        
        Car *toyota = [[Car alloc]initC];
        
        [toyota drive];
        
        
        
        
    }
    return 0;
    
    
    
}
